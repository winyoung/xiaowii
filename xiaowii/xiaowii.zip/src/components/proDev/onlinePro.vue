<template>
    <div>
        <div class="chengkai"></div>
        <div class="title">
            <span style="font-size:20px;color:#8f8f8f;margin-left:20px">线上产品</span>
        </div>
        <div class="online_pro">

        </div>
    </div>
</template>
<style>
@import url("../../assets/css/proDev/onlinePro.css");
</style>
<script>
export default {
  data() {
    return {};
  },
  mounted() {
  }
};
</script>