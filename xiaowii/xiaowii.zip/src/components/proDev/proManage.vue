<template>
    <div class="online_pro">
        这是产品管理页
    </div>
</template>
<style lang="less">
  .online_pro{
      position: absolute;
      top:100px;
       z-index: -1;
  }
</style>
<script>
export default {
    data(){
        return{

        }
    },
    mounted(){
        // this.$store.commit('toggleShow', {isShow: false});
        // console.log(this.$store.state.isShow, 'hotsell');
    }
}
</script>